$ErrorActionPreference = "Stop"

function Ensure-Command {
  param([string]$Name, [string]$Hint)
  if (-not (Get-Command $Name -ErrorAction SilentlyContinue)) {
    Write-Host "$Name is required. $Hint"
    exit 1
  }
}

Ensure-Command -Name "node" -Hint "Install Node 18+ and retry."
Ensure-Command -Name "npm" -Hint "Install Node 18+ (includes npm) and retry."

$TargetDir = Join-Path $env:USERPROFILE ".openclaw\sidecar\parallel-chat"
New-Item -ItemType Directory -Force -Path $TargetDir | Out-Null

@'
import express from "express";
import crypto from "crypto";

const app = express();
app.use(express.json({ limit: "1mb" }));

const GATEWAY = process.env.OPENCLAW_GATEWAY_URL; // e.g. http://127.0.0.1:18789
const TOKEN = process.env.OPENCLAW_GATEWAY_TOKEN || ""; // optional
const MODEL_OVERRIDE = process.env.OPENCLAW_MODEL || ""; // optional
const BIND_HOST = process.env.BIND_HOST || "127.0.0.1";
const PORT = Number(process.env.PORT || 3005);
const SESSION_PREFIX = process.env.SESSION_PREFIX || "agent:main:tab-";

if (!GATEWAY) throw new Error("Set OPENCLAW_GATEWAY_URL");

app.get("/", (_req, res) => res.redirect("/new"));

// Create a fresh independent sessionKey and redirect to a new chat tab
app.get("/new", (_req, res) => {
  const sk = `${SESSION_PREFIX}${crypto.randomUUID()}`;
  res.redirect(`/chat/${encodeURIComponent(sk)}`);
});

async function gatewayFetch(path, init = {}) {
  const headers = {
    ...(TOKEN ? { Authorization: `Bearer ${TOKEN}` } : {}),
    ...init.headers,
  };
  return fetch(`${GATEWAY}${path}`, { ...init, headers });
}

function normalizeModelsPayload(payload) {
  if (Array.isArray(payload)) return payload;
  if (Array.isArray(payload?.data)) return payload.data;
  if (Array.isArray(payload?.models)) return payload.models;
  return [];
}

function pickDefaultModel(models) {
  if (MODEL_OVERRIDE) return MODEL_OVERRIDE;
  const tagged = models.find((m) => (m.tags || []).includes("default"));
  if (tagged?.id) return tagged.id;
  const explicit = models.find((m) => m.default === true);
  if (explicit?.id) return explicit.id;
  return models[0]?.id || "";
}

app.get("/api/models", async (_req, res) => {
  try {
    const upstream = await gatewayFetch("/v1/models");
    if (!upstream.ok) {
      const text = await upstream.text().catch(() => "");
      return res
        .status(upstream.status)
        .json({ error: text || "Failed to load models" });
    }
    const raw = await upstream.json();
    const models = normalizeModelsPayload(raw)
      .filter((m) => m && typeof m.id === "string")
      .map((m) => ({
        id: m.id,
        tags: Array.isArray(m.tags)
          ? m.tags
          : Array.isArray(m.metadata?.tags)
            ? m.metadata.tags
            : [],
      }));
    return res.json({ models, defaultModel: pickDefaultModel(models) });
  } catch (err) {
    return res.status(500).json({ error: String(err?.message || err) });
  }
});

app.post("/api/chat", async (req, res) => {
  const { sessionKey, model, messages } = req.body || {};
  if (!sessionKey || !Array.isArray(messages)) {
    return res.status(400).json({ error: "Missing sessionKey or messages" });
  }
  const upstream = await gatewayFetch("/v1/chat/completions", {
    method: "POST",
    headers: {
      "Content-Type": "application/json",
      "x-openclaw-session-key": sessionKey,
    },
    body: JSON.stringify({
      model,
      messages,
      stream: true,
    }),
  });

  res.status(upstream.status);
  res.setHeader("Content-Type", "text/event-stream; charset=utf-8");
  res.setHeader("Cache-Control", "no-cache");
  res.setHeader("Connection", "keep-alive");

  if (!upstream.ok || !upstream.body) {
    const text = await upstream.text().catch(() => "");
    res.write(`data: ${JSON.stringify({ error: text || "Upstream error" })}\n\n`);
    res.write("data: [DONE]\n\n");
    return res.end();
  }

  const reader = upstream.body.getReader();
  while (true) {
    const { value, done } = await reader.read();
    if (done) break;
    res.write(value);
  }
  res.end();
});

app.get("/chat/:sk", (req, res) => {
  const sk = req.params.sk;

  res.type("html").send(`<!doctype html>
<meta charset="utf-8" />
<title>OpenClaw Parallel Chat</title>
<style>
  body{font-family:system-ui,sans-serif;max-width:960px;margin:24px auto;padding:0 12px}
  #top{display:flex;justify-content:space-between;align-items:center;gap:12px}
  #log{border:1px solid #ddd;padding:12px;min-height:360px;white-space:pre-wrap;overflow:auto}
  #row{display:flex;gap:8px;margin-top:12px}
  #msg{flex:1;font-size:14px;padding:8px}
  button, select{font-size:14px;padding:8px 10px}
  code{background:#f6f6f6;padding:2px 4px;border-radius:4px}
</style>

<div id="top">
  <div>
    <div><strong>OpenClaw Parallel Chat</strong></div>
    <div>sessionKey: <code id="sk"></code></div>
  </div>
  <div>
    <select id="model"></select>
    <button id="stop" disabled>Stop</button>
    <button id="newtab">New tab</button>
  </div>
</div>

<div id="log"></div>

<div id="row">
  <input id="msg" placeholder="Type…" />
  <button id="send">Send</button>
</div>

<script>
const SESSION_KEY=${JSON.stringify(sk)};
const MODEL_OVERRIDE=${JSON.stringify(MODEL_OVERRIDE)};

document.getElementById('sk').textContent = SESSION_KEY;

const log = document.getElementById('log');
const msg = document.getElementById('msg');
const sendBtn = document.getElementById('send');
const stopBtn = document.getElementById('stop');
const newTabBtn = document.getElementById('newtab');
const modelSel = document.getElementById('model');

async function loadModels() {
  try {
    const res = await fetch('/api/models');
    const data = await res.json();
    const models = Array.isArray(data.models) ? data.models : [];
    const defaultModel = data.defaultModel || MODEL_OVERRIDE || models[0]?.id || '';
    for (const m of models) {
      const opt = document.createElement('option');
      opt.value = m.id;
      opt.textContent = m.id + (m.tags?.includes('default') ? ' (default)' : '');
      modelSel.appendChild(opt);
    }
    if (defaultModel) modelSel.value = defaultModel;
  } catch (e) {
    const opt = document.createElement('option');
    opt.value = MODEL_OVERRIDE || 'openrouter/auto';
    opt.textContent = opt.value + ' (fallback)';
    modelSel.appendChild(opt);
    modelSel.value = opt.value;
  }
}
loadModels();

let messages = [];
let inflight = null;

function appendLine(text){
  log.textContent += text;
  log.scrollTop = log.scrollHeight;
}

function appendUser(text){
  appendLine(`\nUSER: ${text}\n`);
}

function beginAssistant(){
  appendLine('ASSISTANT: ');
}

function appendAssistantDelta(delta){
  appendLine(delta);
}

function endAssistant(){
  appendLine('\n');
}

function consumeSse(buffer) {
  const parts = buffer.split(/\n\n/);
  const remainder = parts.pop() ?? '';
  const events = [];
  for (const raw of parts) {
    const lines = raw.split(/\n/);
    const dataLines = [];
    for (const line of lines) {
      if (line.startsWith('data:')) dataLines.push(line.slice(5).trimStart());
    }
    if (dataLines.length) events.push(dataLines.join('\n'));
  }
  return { events, remainder };
}

async function send(){
  const text = msg.value.trim();
  if (!text || inflight) return;

  msg.value = '';
  appendUser(text);
  messages.push({ role: 'user', content: text });

  beginAssistant();

  const controller = new AbortController();
  inflight = controller;
  stopBtn.disabled = false;
  sendBtn.disabled = true;

  let assistantText = '';
  let buf = '';
  const decoder = new TextDecoder();

  try {
    const res = await fetch('/api/chat', {
      method: 'POST',
      signal: controller.signal,
      headers: {
        'Content-Type': 'application/json'
      },
      body: JSON.stringify({
        sessionKey: SESSION_KEY,
        model: modelSel.value,
        messages
      })
    });

    if (!res.ok || !res.body) {
      const t = await res.text().catch(() => '');
      appendAssistantDelta(`\n[HTTP ${res.status}] ${t}\n`);
      endAssistant();
      return;
    }

    const reader = res.body.getReader();

    while (true) {
      const { value, done } = await reader.read();
      if (done) break;

      buf += decoder.decode(value, { stream: true });

      const parsed = consumeSse(buf);
      buf = parsed.remainder;

      for (const payload of parsed.events) {
        if (payload === '[DONE]') {
          endAssistant();
          messages.push({ role: 'assistant', content: assistantText });
          return;
        }
        try {
          const obj = JSON.parse(payload);
          const delta = obj?.choices?.[0]?.delta?.content;
          if (delta) {
            assistantText += delta;
            appendAssistantDelta(delta);
          }
        } catch {
          // ignore non-JSON keepalives
        }
      }
    }

    endAssistant();
    messages.push({ role: 'assistant', content: assistantText });

  } catch (e) {
    if (String(e?.name) === 'AbortError') {
      appendAssistantDelta('\n[stopped]\n');
      endAssistant();
      if (assistantText) messages.push({ role: 'assistant', content: assistantText });
    } else {
      appendAssistantDelta(`\n[error] ${e?.message || e}\n`);
      endAssistant();
    }
  } finally {
    inflight = null;
    stopBtn.disabled = true;
    sendBtn.disabled = false;
  }
}

stopBtn.onclick = () => {
  if (inflight) inflight.abort();
};

sendBtn.onclick = send;
msg.addEventListener('keydown', (e) => (e.key === 'Enter' ? send() : null));

newTabBtn.onclick = () => {
  window.open('/new', '_blank', 'noopener');
};

appendLine('SYSTEM: Ready. This tab is an isolated session lane.\n');
</script>`);
});

app.listen(PORT, BIND_HOST, () => {
  console.log(`Sidecar listening on http://${BIND_HOST}:${PORT}/new`);
});
'@ | Set-Content -Path (Join-Path $TargetDir "server.js") -Encoding UTF8

@'
{
  "name": "openclaw-parallel-sidecar",
  "private": true,
  "type": "module",
  "version": "0.1.0",
  "engines": {
    "node": ">=18"
  },
  "scripts": {
    "start": "node server.js"
  },
  "dependencies": {
    "express": "^4.19.2"
  }
}
'@ | Set-Content -Path (Join-Path $TargetDir "package.json") -Encoding UTF8

Push-Location $TargetDir
npm install
Pop-Location

$ConfigFile = Join-Path $env:USERPROFILE ".openclaw\openclaw.json"
Write-Host ""
$reply = Read-Host "Enable OpenClaw gateway HTTP chat endpoint? (required for sidecar; gateway will be restarted) [y/N]"
if ($reply -match '^[yY]') {
  if (Test-Path $ConfigFile) {
    $env:OPENCLAW_CONFIG_PATH = $ConfigFile
    node -e "const fs=require('fs');const p=process.env.OPENCLAW_CONFIG_PATH;let j={};try{j=JSON.parse(fs.readFileSync(p,'utf8'));}catch(e){};j.gateway=j.gateway||{};j.gateway.http=j.gateway.http||{};j.gateway.http.endpoints=j.gateway.http.endpoints||{};j.gateway.http.endpoints.chatCompletions=j.gateway.http.endpoints.chatCompletions||{};j.gateway.http.endpoints.chatCompletions.enabled=true;fs.writeFileSync(p,JSON.stringify(j,null,2));"
    Write-Host "✓ Config updated (HTTP chat endpoint enabled)."
    Write-Host ""
    Write-Host "⚠️  IMPORTANT: Restart your gateway for changes to take effect:"
    Write-Host "   1. Stop the gateway (Ctrl+C if running in foreground, or: Stop-Process -Name openclaw-gateway)"
    Write-Host "   2. Start it again: openclaw gateway"
    Write-Host ""
  } else {
    Write-Host "Config not found at $ConfigFile. Enable gateway.http.endpoints.chatCompletions.enabled manually and run: openclaw gateway stop; openclaw gateway"
  }
}

Write-Host ""
Write-Host "Install complete."
Write-Host ""
Write-Host "Next steps:"
Write-Host "  `$env:OPENCLAW_GATEWAY_URL = `"http://127.0.0.1:18789`""
Write-Host "  # `$env:OPENCLAW_GATEWAY_TOKEN = `"...`""
Write-Host "  npm start"
Write-Host ""
Write-Host "Open:"
Write-Host "  http://127.0.0.1:3005/new"

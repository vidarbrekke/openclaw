/**
 * Silent Checklist Plugin
 *
 * Injects a silent preflight instruction into the system prompt for all agent runs.
 * Uses prependContext (the only field the embedded runner actually consumes from
 * the before_agent_start hook result). The text appears before the system prompt.
 */

export default function register(api) {
  const PREFLIGHT_TEXT =
    "Silent preflight: before finalizing, map each failing test/assertion to the exact change that fixes it; if you can't, say what's missing. Do not output the mapping—only the final tool calls/response.";

  const STRUCTURED_OUTPUT_GUARD =
    "If this run requires structured stdout (json/jsonl), output ONLY valid JSON/JSONL and nothing else (no prose).";

  api.on("before_agent_start", (event) => {
    const cfg = (event && event.config) || {};
    if (cfg.enabled === false) return;

    // Best-effort de-dupe (avoid repeated injections if upstream already added it)
    const hay = [
      typeof event?.prompt === "string" ? event.prompt : "",
      typeof event?.systemPrompt === "string" ? event.systemPrompt : "",
      typeof event?.prependContext === "string" ? event.prependContext : "",
    ].join("\n");

    if (hay.includes(PREFLIGHT_TEXT)) {
      return;
    }

    let prepend = PREFLIGHT_TEXT;

    // Optional guard: only add if explicitly enabled AND we can detect output mode
    if (cfg.extraStructuredOutputGuard) {
      const mode = event?.outputMode || event?.requesterOrigin?.outputMode || event?.channelOutputMode;
      if (mode === "json" || mode === "jsonl") {
        prepend = `${prepend}\n${STRUCTURED_OUTPUT_GUARD}`;
      }
    }

    return { prependContext: prepend };
  });
}
